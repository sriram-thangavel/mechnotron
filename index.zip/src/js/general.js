// const observer = new IntersectionObserver(entries => {
//     entries.forEach(entry => {
//       const square = entry.target.querySelector('.about_achievements__about--title');
  
//       if (entry.isIntersecting) {
//         square.classList.add('tracking-in-expand-fwdr');
//         return; // if we added the class, exit the function
//       }
  
//       // We're not intersecting, so remove the class!
//       square.classList.remove('tracking-in-expand-fwd');
//     });
//   });
  
//   observer.observe(document.querySelector('about_achievementst'));



  let OpenBtn = document.querySelector('.bi-list');
  let CloseBtn = document.querySelector(".bi-x-lg");
  let menu = document.querySelector(".navbar__menu");
  let menuItems = document.querySelectorAll(".navbar__menu--item");

  OpenBtn.addEventListener("click",()=>{
    OpenBtn.classList.toggle('hide');
    CloseBtn.classList.toggle('hide');
    menu.classList.toggle("hidden");

  });

  CloseBtn.addEventListener("click",()=>{
    OpenBtn.classList.toggle('hide');
    CloseBtn.classList.toggle('hide');
    menu.classList.toggle("hidden");
    
  });

menuItems.forEach((item) => {
  item.addEventListener("click",()=>{
    OpenBtn.classList.toggle('hide');
    CloseBtn.classList.toggle('hide');
    menu.classList.toggle("hidden");
    });
  
});

